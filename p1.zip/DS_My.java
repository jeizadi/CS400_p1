
public class DS_My implements DataStructureADT {

    // TODO may wish to define an inner class 
    // for storing key and value as a pair
    // such a class and its members should be "private"

    // Private Fields of the class
    // TODO create field(s) here to store data pairs
    
    public DS_My() {
        // TODO Auto-generated method stub
        
    }

    @Override
    public void insert(Comparable k, Object v) {
        // TODO Auto-generated method stub
        
    }

    @Override
    public boolean remove(Comparable k) {
        // TODO Auto-generated method stub
        return false;
    }

    @Override
    public boolean contains(Comparable k) {
        // TODO Auto-generated method stub
        return false;
    }

    @Override
    public Object get(Comparable k) {
        // TODO Auto-generated method stub
        return null;
    }

    @Override
    public int size() {
        // TODO Auto-generated method stub
        return 0;
    }

}
